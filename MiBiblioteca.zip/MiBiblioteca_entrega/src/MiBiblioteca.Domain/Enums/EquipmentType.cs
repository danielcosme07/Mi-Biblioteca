namespace MiBiblioteca.Domain.Enums;

public enum EquipmentType
{
    Laptop = 1,
    Tablet = 2,
    Projector = 3,
    Other = 4
}
