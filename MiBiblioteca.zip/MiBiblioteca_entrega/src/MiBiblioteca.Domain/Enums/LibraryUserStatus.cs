namespace MiBiblioteca.Domain.Enums;

public enum LibraryUserStatus
{
    Active = 1,
    Suspended = 2
}
