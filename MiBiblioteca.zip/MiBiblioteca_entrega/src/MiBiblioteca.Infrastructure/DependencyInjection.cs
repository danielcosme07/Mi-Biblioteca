using MiBiblioteca.Application.Contracts;
using MiBiblioteca.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace MiBiblioteca.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddMiBibliotecaInfrastructure(
        this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("MiBiblioteca")
            ?? "Server=localhost;Port=3306;Database=mi_biblioteca;User=mi_biblioteca;Password=mi_biblioteca;";
        var serverVersion = Version.Parse(configuration["Database:ServerVersion"] ?? "8.0.46");
        services.AddDbContext<MiBibliotecaDbContext>(options =>
            options.UseMySql(connectionString, new MySqlServerVersion(serverVersion)));
        services.AddScoped<ILibraryUserRepository, LibraryUserRepository>();
        services.AddScoped<ILibraryResourceRepository, LibraryResourceRepository>();
        services.AddScoped<ILoanRepository, LoanRepository>();
        services.AddScoped<IUnitOfWork, EfUnitOfWork>();
        return services;
    }
}
