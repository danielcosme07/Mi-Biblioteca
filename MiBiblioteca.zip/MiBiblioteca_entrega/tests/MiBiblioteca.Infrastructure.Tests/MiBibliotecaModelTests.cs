using MiBiblioteca.Infrastructure.Persistence;
using MiBiblioteca.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace MiBiblioteca.Infrastructure.Tests;

public sealed class MiBibliotecaModelTests
{
    [Fact]
    public void MySql_model_maps_library_tables_and_resource_relationships()
    {
        var options = new DbContextOptionsBuilder<MiBibliotecaDbContext>()
            .UseMySql("Server=localhost;Database=mi_biblioteca;User=mi_biblioteca;Password=placeholder;",
                new MySqlServerVersion(new Version(8, 4, 0)))
            .Options;
        using var context = new MiBibliotecaDbContext(options);
        var model = context.Model;

        Assert.NotNull(model.FindEntityType("MiBiblioteca.Domain.Entities.LibraryUser")?.GetTableName());
        Assert.Equal("Users", model.FindEntityType(typeof(MiBiblioteca.Domain.Entities.LibraryUser))?.GetTableName());
        Assert.Equal("Resources", model.FindEntityType(typeof(MiBiblioteca.Domain.Entities.LibraryResource))?.GetTableName());
        Assert.Equal("Books", model.FindEntityType(typeof(MiBiblioteca.Domain.Entities.Book))?.GetTableName());
        Assert.Equal("Equipment", model.FindEntityType(typeof(MiBiblioteca.Domain.Entities.Equipment))?.GetTableName());
        Assert.Equal("Loans", model.FindEntityType(typeof(MiBiblioteca.Domain.Entities.Loan))?.GetTableName());
    }

    [Fact]
    public void Loan_foreign_key_enforces_the_resource_kind()
    {
        var options = new DbContextOptionsBuilder<MiBibliotecaDbContext>()
            .UseMySql("Server=localhost;Database=mi_biblioteca;User=mi_biblioteca;Password=placeholder;",
                new MySqlServerVersion(new Version(8, 4, 0)))
            .Options;
        using var context = new MiBibliotecaDbContext(options);
        var loan = context.Model.FindEntityType(typeof(Loan))!;
        var resourceForeignKey = Assert.Single(loan.GetForeignKeys()
            .Where(key => key.PrincipalEntityType.ClrType == typeof(LibraryResource)));

        Assert.Equal(new[] { "ResourceId", "ResourceKind" }, resourceForeignKey.Properties.Select(property => property.Name));
        Assert.Equal(new[] { "Id", "Kind" }, resourceForeignKey.PrincipalKey.Properties.Select(property => property.Name));
    }
}
