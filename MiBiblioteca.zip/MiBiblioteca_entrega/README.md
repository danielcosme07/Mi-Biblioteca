# MiBiblioteca

API educativa de biblioteca para registrar usuarios, libros y equipos, consultar disponibilidad y gestionar préstamos y devoluciones. La solución apunta a **.NET 8** para ejecutarse en los equipos de la universidad.

**Autor:** Daniel Cosme

## Estructura

- `src/MiBiblioteca.Domain`: entidades, estados e invariantes de biblioteca.
- `src/MiBiblioteca.Application`: casos de uso y contratos de persistencia.
- `src/MiBiblioteca.Infrastructure`: EF Core 8, mapeos y persistencia MySQL.
- `src/MiBiblioteca.Api`: controladores REST, DTO de entrada y composición.
- `tests`: pruebas de dominio, aplicación, API, arquitectura, persistencia y ejercicios.
- `specs`: especificaciones funcionales y técnicas.

Las dependencias apuntan hacia el dominio: `Api -> Application -> Domain <- Infrastructure`. Los controladores no contienen reglas de préstamo.

## Requisitos

- SDK de .NET 8.
- MySQL 8.0.16 o posterior instalado localmente (también compatible con MySQL 8.4).
- NuGet disponible para restaurar los paquetes al preparar el equipo.

No se usan SQL Server, PostgreSQL, SQLite ni persistencia InMemory.

## Preparar MySQL local

Instala e inicia MySQL localmente y crea una base de datos llamada `mi_biblioteca` y un usuario con permisos sobre esa base. El proyecto no incluye contenedores ni herramientas de orquestación.

Desde MySQL Workbench o el cliente MySQL, con una cuenta administradora, puedes preparar una cuenta propia de desarrollo. Sustituye `CAMBIAR` por tu contraseña local:

```sql
CREATE DATABASE IF NOT EXISTS mi_biblioteca CHARACTER SET utf8mb4;
CREATE USER 'mi_biblioteca'@'localhost' IDENTIFIED BY 'CAMBIAR';
GRANT ALL PRIVILEGES ON mi_biblioteca.* TO 'mi_biblioteca'@'localhost';
```

## Restaurar, migrar e iniciar

Desde la raíz de esta carpeta:

```powershell
dotnet restore
dotnet tool restore
```

Configura la conexión mediante variables de entorno de .NET. Ejemplo para PowerShell con credenciales locales de desarrollo:

```powershell
$env:ConnectionStrings__MiBiblioteca = "Server=localhost;Port=3306;Database=mi_biblioteca;User=mi_biblioteca;Password=CAMBIAR;"
$env:Database__ServerVersion = "8.0.46"
```

Usa la versión que muestra `SELECT VERSION()` en tu servidor. Mantén las credenciales en variables de entorno o secretos de desarrollo, fuera del código y de Git.

Como alternativa para este equipo, en entorno Development puedes guardar la conexión con el administrador de secretos de .NET:

```powershell
dotnet user-secrets set "ConnectionStrings:MiBiblioteca" "Server=localhost;Port=3306;Database=mi_biblioteca;User=mi_biblioteca;Password=CAMBIAR;" --project src/MiBiblioteca.Api
```

El proyecto API ya tiene `UserSecretsId`. Los secretos se guardan en el perfil del usuario; no viajan al copiar el proyecto a otro computador. Una variable `ConnectionStrings__MiBiblioteca` tiene prioridad sobre esos secretos.

Aplica la migración inicial:

```powershell
dotnet ef database update --project src/MiBiblioteca.Infrastructure --startup-project src/MiBiblioteca.Api
```

Para insertar los datos educativos de ejemplo al iniciar la API, activa la inicialización:

```powershell
$env:Database__InitializeOnStartup = "true"
dotnet run --project src/MiBiblioteca.Api
```

La inicialización aplica migraciones pendientes y agrega un usuario, un libro y un equipo de demostración solo si sus tablas están vacías. Swagger queda disponible en `/swagger` en entorno Development.

Con el perfil HTTP predeterminado, abre `http://localhost:5109/swagger`. Los tipos de equipo son `1` portátil, `2` tableta, `3` proyector y `4` otro. Una fecha límite de préstamo se envía en formato ISO 8601, por ejemplo con sufijo `Z` para UTC.

Para crear otra migración después de cambiar el modelo:

```powershell
dotnet ef migrations add NombreDelCambio --project src/MiBiblioteca.Infrastructure --startup-project src/MiBiblioteca.Api --output-dir Persistence/Migrations
```

## Endpoints

| Método | Ruta | Uso |
|---|---|---|
| GET, POST | `/api/users` | Consultar y registrar usuarios |
| GET, POST | `/api/books` | Consultar y registrar libros |
| GET | `/api/books/{id}` | Consultar libro y disponibilidad |
| GET, POST | `/api/equipment` | Consultar y registrar equipos |
| GET | `/api/equipment/{id}` | Consultar equipo y disponibilidad |
| GET, POST | `/api/loans` | Consultar préstamos y prestar un recurso |
| GET | `/api/loans/{id}` | Consultar un préstamo |
| POST | `/api/loans/{id}/return` | Devolver un préstamo activo |

El préstamo recibe `userId`, `resourceId` y `dueAt`. El recurso puede ser libro o equipo; el dominio conserva su tipo. La disponibilidad se protege con una transacción y control de concurrencia.

## Pruebas

```powershell
dotnet test tests/MiBiblioteca.Domain.Tests
dotnet test tests/MiBiblioteca.Application.Tests
dotnet test tests/MiBiblioteca.Api.Tests
dotnet test tests/MiBiblioteca.Architecture.Tests
dotnet test tests/MiBiblioteca.Infrastructure.Tests
```

Las pruebas anteriores cubren reglas normales y el modelo relacional. Las cinco pruebas en `MiBiblioteca.Patterns.Tests` deben fallar mientras el estudiante no resuelva los ejercicios:

```powershell
dotnet test tests/MiBiblioteca.Patterns.Tests
```

No se omiten, ignoran ni debilitan. Consulta `specs/exercises.md` para ver qué comportamiento observa cada una sin instrucciones de solución.

Con la API iniciada y conectada a MySQL, ejecuta la verificación de integración real:

```powershell
powershell -NoProfile -File .\scripts\Verify-MiBiblioteca.ps1 -ApiBaseUrl http://localhost:5109
```

Comprueba registros, consultas, préstamos, devoluciones, conflictos y dos solicitudes concurrentes para el mismo recurso. Crea y conserva registros con prefijo `VERIFY`; úsalo en una base de desarrollo. Las pruebas HTTP de xUnit usan repositorios de prueba y no sustituyen esta comprobación de MySQL.

## Actividad académica

Factory Method, Builder, Adapter, Decorator y Facade están intencionalmente pendientes. `AGENTS.md`, los `TODO(STUDENT)` y sus pruebas preservan esos límites. No completes esos ejercicios automáticamente.

## Especificaciones

- [Arquitectura](specs/architecture.md)
- [Dominio](specs/domain.md)
- [API](specs/api.md)
- [MySQL](specs/database.md)
- [Ejercicios](specs/exercises.md)
- [Propuesta OpenSpec](openspec/changes/create-mibiblioteca/proposal.md)
- [Tareas OpenSpec](openspec/changes/create-mibiblioteca/tasks.md)
